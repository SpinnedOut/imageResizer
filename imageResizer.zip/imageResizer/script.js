const fileInput = document.getElementById('fileInput');
const widthInput = document.getElementById('width');
const heightInput = document.getElementById('height');
const resizeButton = document.getElementById('resizeButton');
const imagePreview = document.getElementById('imagePreview');
const downloadButton = document.getElementById('downloadButton');
const originalDimensions = document.getElementById('originalDimensions');

fileInput.addEventListener('change', function() {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            imagePreview.src = e.target.result;
            // When the image loads, display its dimensions
            imagePreview.onload = function() {
                originalDimensions.textContent = `Original Dimensions: ${this.width} x ${this.height}`;
            }
        };
        reader.readAsDataURL(file);
    } else {
        // If no image is selected, reset the displayed dimensions
        originalDimensions.textContent = 'Original Dimensions: - x -';
    }
});

resizeButton.addEventListener('click', async function() {
    if (!fileInput.files.length) return alert('Please select an image.');
    if (!widthInput.value || !heightInput.value) return alert('Please specify both width and height.');

    const img = new Image();
    img.src = imagePreview.src;

    img.onload = async function() {
        const offScreenCanvas = document.createElement('canvas');
        offScreenCanvas.width = Number(widthInput.value);
        offScreenCanvas.height = Number(heightInput.value);

        await pica().resize(img, offScreenCanvas);
        
        imagePreview.src = offScreenCanvas.toDataURL('image/jpeg');
        downloadButton.removeAttribute('disabled');
    }
});

downloadButton.addEventListener('click', function() {
    const selectedFormat = document.getElementById('formatSelector').value;
    let fileExtension;

    switch (selectedFormat) {
        case 'image/jpeg':
            fileExtension = 'jpg';
            break;
        case 'image/png':
            fileExtension = 'png';
            break;
        case 'image/gif':
            fileExtension = 'gif';
            break;
        default:
            fileExtension = 'jpg';
    }

    const a = document.createElement('a');
    a.href = imagePreview.src;
    a.download = `resized-image.${fileExtension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
});
